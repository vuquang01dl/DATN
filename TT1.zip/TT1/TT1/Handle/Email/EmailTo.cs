﻿namespace TT1.Handle.Email
{
    public class EmailTo
    {
        public string Mail { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
    }
}
