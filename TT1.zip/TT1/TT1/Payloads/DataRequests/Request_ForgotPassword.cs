﻿namespace TT1.Payloads.DataRequests
{
    public class Request_ForgotPassword
    {
        public string email { get; set; }
    }
}
