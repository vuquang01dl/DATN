﻿namespace ThucTapW1._1.Payloads.DataRequests
{
    public class Request_Login
    {
        public string user_name { get; set; }
        public string password  { get; set; }
    }
}
