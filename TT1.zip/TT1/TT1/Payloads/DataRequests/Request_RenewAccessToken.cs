﻿namespace ThucTapW1._1.Payloads.DataRequests
{
    public class Request_RenewAccessToken
    {
        public string RefreshToken { get; set; }
    }
}
