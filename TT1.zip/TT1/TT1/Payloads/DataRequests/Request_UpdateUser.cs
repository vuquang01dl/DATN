﻿namespace TT1.Payloads.DataRequests
{
    public class Request_UpdateUser
    {
        public string phone { get; set; }
        public string email { get; set; }
        public string address { get; set; }
    }
}
