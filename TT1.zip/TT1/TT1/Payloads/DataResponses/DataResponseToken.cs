﻿namespace TT1.Payloads.DataResponses
{
    public class DataResponseToken
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
    }
}
