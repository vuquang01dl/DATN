﻿namespace TT1.Payloads.DataResponses
{
    public class DataResponseUser
    {
        //user
        public string user_name { get; set; }
        public string avata { get; set; }
        public int status { get; set; }      
        public string phone { get; set; }
        public string email { get; set; }
        public string address { get; set; }
    }
}
