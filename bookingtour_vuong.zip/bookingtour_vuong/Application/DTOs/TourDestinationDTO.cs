﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Application.DTOs
{
    public class TourDestinationDTO
    {
        public Guid TourID { get; set; }
        public Guid DestinationID { get; set; }
    }
}
