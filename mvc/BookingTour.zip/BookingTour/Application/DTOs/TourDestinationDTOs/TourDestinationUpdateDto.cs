﻿namespace Application.DTOs.TourDestinationDTOs
{
    public class TourDestinationUpdateDto
    {
        public DateTime VisitDate { get; set; }
    }
}
