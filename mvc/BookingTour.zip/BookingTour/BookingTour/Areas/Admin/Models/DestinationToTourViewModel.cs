﻿namespace Presentation.Areas.Admin.Models
{
    public class DestinationToTourViewModel
    {
        public Guid TourID { get; set; }
        public Guid Destinationn { get; set; }
        public DateTime VisitDate { get; set; }
    }
}
