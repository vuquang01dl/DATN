<template>
  <DefaultLayout />
</template>

<script>
import DefaultLayout from './layout/DefaultLayout.vue'
export default {
  components: { DefaultLayout }
}
</script>
