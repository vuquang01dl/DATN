<template>
  <footer class="footer mt-auto py-4 bg-light border-top">
    <div class="container text-center">
      <div class="mb-2">
        <strong>BookingTour</strong> | 123 Trần Phú, Đà Nẵng<br />
        Số điện thoại: 0123 456 789 | Email: support@bookingtour.vn<br />
        Thời gian làm việc: 8h - 17h (Thứ 2 - Thứ 7)
      </div>

      <div class="social-links mt-2">
        <a href="#" class="text-muted me-3"><i class="bi bi-facebook fs-5"></i></a>
        <a href="#" class="text-muted me-3"><i class="bi bi-instagram fs-5"></i></a>
        <a href="#" class="text-muted"><i class="bi bi-twitter fs-5"></i></a>
      </div>

      <div class="mt-2 small text-muted">
        &copy; 2025 BookingTour. All rights reserved.
      </div>
    </div>
  </footer>
</template>

<style scoped>
.footer {
  font-size: 14px;
  color: #444;
}

.social-links i:hover {
  color: #007bff;
  transition: color 0.2s;
}
</style>
